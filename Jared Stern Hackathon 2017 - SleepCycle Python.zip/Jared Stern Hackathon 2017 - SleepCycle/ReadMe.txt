Jared Stern
sternjar@kean.edu

I claim that I am the author of 
SleepCycle.py
my submission for the Kean 2017 Hackathon, and all other files and information in this are not mine.
My personal sleep data in included .edf files is shared for demonstration purposes