import sqlite3
from bitstring import ConstBitStream
import binascii
from collections import deque
import datetime
import codecs
        
con = sqlite3.connect(":memory:")
con.isolation_level = None
cur = con.cursor()

buffer = ""

cur.execute('''CREATE TABLE sleepEvents (dateStarted text, dateEnded text, timeSec text, eventType text)''')



#replace with any file encoded in S9 format, ID'd with _____EVE.edf
s = ConstBitStream(filename = '20170331_215629_EVE.edf')
s.pos == 0

#finds the next instance of a character by forcing position compliance.
#additonal code breaks loops if that character DNE in the soruce file.
def findNextChar(searchbytes):
    found = s.find(searchbytes, s.pos, bytealigned=True)

'''
#construct datetime officially
#from pos 168-169 DD 171-172 MM 174-175 yy
sDate = s
sDate.pos = 168*8
day = sDate.read('bytes:2')
sDate.pos = 171*8
month = sDate.read('bytes:2')
sDate.pos = 174*8
year = sDate.read('bytes:2')
sDate.pos = 176*8
hours = sDate.read('bytes:2')
sDate.pos = 179*8
minutes = sDate.read('bytes:2')
sDate.pos = 182*8
seconds = sDate.read('bytes:2')
print (day)
print (month)
print (year)
year += 2000
startDate = datetime.datetime(year, month, day, hours, minutes, seconds)
value = (binascii.unhexlify(month))
print (int.from_bytes(value, byteorder='big'))
'''




#create two queues to log entry for later input
timeLog = deque()
eventLog = deque()
#print (list(timeLog))
timeCount = 0
eventCount = 0


sTemp = s
#print (sTemp)
findNextChar('0x2B')
s.pos += 8
#print (s)
setup = s.find('0x2B', bytealigned=True)
while len(setup) != 0:
        s.pos += 8
        test = s.peek(8)
        if test != '0x30' and test in ['0x31', '0x32', '0x33', '0x34', '0x35', '0x36', '0x37', '0x38', '0x39',]:
            print ('valid result, bytecode for time passed in seconds follows')
            savedResult = s.readto('0x15', bytealigned=True)
            savedResult = savedResult[:-8]
            #SavedResult is the proper hex values for the events at this time
            print (savedResult.hex)
            timeLog.append(savedResult.hex)
            timeCount += 1
        s = s[s.pos:]    
        setup = s.find('0x2B', bytealigned=True)
#print ('hello')
#print (list(timeLog))
#print (timeLog.popleft())
#print ('goodbye')

#print (sTemp)



sTemp.pos = 0
#generic implementation: steps through each value to find info
#print (sTemp.len)
endCondition = sTemp.find('0x14', bytealigned=True)

while len(endCondition) !=0:
    testVal = sTemp.read(8)
    #print(testVal)
    if testVal == '0x14':
        testVal = sTemp.read(8)
        #print(testVal)
        if testVal == '0x14':
            sTemp.pos += 8
        if testVal in ['0x41', '0x4f', '0x43', '0x48']:
            savedEvent = testVal + sTemp.readto('0x14', bytealigned=True)
            savedEvent = savedEvent[:-8]
            #clear out leading 0x so I can safely convert back to string for non-conflicting output
            save = str(savedEvent)
            save = save[2:]
            #safeltext output of finalized results, to be saved to sql
            textOutput = ''.join(chr(int(save[i:i+2], 16)) for i in range(0, len(save), 2))
            print('following text is the string extracted from text file corresponding to incident type.')
            print (textOutput)
            eventLog.append(textOutput)
            eventCount += 1
     #   TestSave = sTemp.peek(8)
        #print (sTemp.peek(8))
      #  sTemp.pos += 8
       # sTemp.pos += 8
        #
         #   savedEvent = sTemp.readto('0x14', bytealigned=True)
          #  savedEvent = savedEvent[:-8]
        #    print(savedEvent)
           # sTemp.pos += 8
            #pointer += 8
           # break.
    sTemp = sTemp[sTemp.pos:]
    endCondition = sTemp.find('0x14', bytealigned=True)
#def accurateTime

#print (sTemp)

for i in range(0, timeCount - 1):
    timeUpdt = timeLog[i]
    eventUpdt = eventLog[i]
    cur.execute('insert into sleepEvents values(0, 0, ?, ?)', (timeUpdt, eventUpdt))
print('#The following table includes the selected data from the sourcefile. Datafields, in order:')
print('dateStarted text(blank by default), dateEnded text(blank by default), timeSec text(hex encoding of seconds since event began), eventType text')
for row in cur.execute('SELECT * from sleepEvents'):
    print (row)

con.close()
